# The Balloon Effect

Jogo educativo para o Global Day 2026 (tema "Américas").
O jogador é o governo dos EUA e tenta bloquear rotas de tráfico — mas cada
rota fechada faz o fluxo reaparecer em outra: o **efeito balão**.

## Como rodar no macOS

1. Verifique se o Python 3 está instalado. No Terminal:
   ```bash
   python3 --version
   ```
   Se não estiver, baixe em https://www.python.org/downloads/
2. Instale o Pygame (só precisa fazer uma vez):
   ```bash
   python3 -m pip install pygame
   ```
3. Entre na pasta do jogo e rode:
   ```bash
   cd caminho/para/balloon-effect
   python3 main.py
   ```

Dica para a exposição: abra o jogo, aperte **F** para tela cheia e deixe na
tela inicial. O mapa de fundo já mostra o efeito balão acontecendo sozinho.

## Controles

- **Mouse / trackpad**: tudo no jogo.
- **F**: liga/desliga tela cheia.
- **Esc**: fecha o jogo (para quem cuida da mesa).

## Como a partida funciona

| Fase | Época | Mecânica nova |
|------|-------|---------------|
| 1 | 1980s | Tutorial: 2 rotas (Caribe e México). Clique numa rota para bloquear. |
| 2 | 1990s | Clique num cartel (Medellín ou Cali) para derrubá-lo: ele se divide em 3 grupos menores. |
| 3 | 2000s | Botões POLICE / MILITARY. O militar segura o tráfico por mais tempo, mas a violência dispara. |
| 4 | 2020s | Fentanil: muitas rotas minúsculas. Cada bloqueio faz surgir uma rota nova. |

- Cada fase dura 33 s e começa com $5B. Antes dela aparece um cartão de
  abertura de 7 s (o tempo da fase não corre enquanto ele aparece).
- Quando os traficantes acham a primeira rota nova da fase, o resto da fase
  roda 2x mais rápido (aparece "2x" ao lado do tempo). Ajuste em
  `FAST_FORWARD_SPEED`, no `settings.py`.
- Depois de cada fase (inclusive a última) aparece um fact card, que fica na
  tela até o visitante clicar em **OK**.
- A partida leva cerca de 2 min 32 s mais o tempo de leitura dos 4 fact cards.
  A tela final fica 20 s (ou até um clique) e volta para o início.
- Se ninguém mexer no mouse por 30 s, o jogo volta para a tela inicial.

## Arquivos

| Arquivo        | O que faz |
|----------------|-----------|
| `main.py`      | Abre a janela, roda o laço principal e troca de tela (máquina de estados). Também cuida da inatividade e do "fade" entre telas. |
| `screens.py`   | As telas: inicial, fase, fact card e final. Só desenho e cliques. |
| `mapview.py`   | Desenha o mapa (rotas, países, pontinhos, X) e as animações curtas. |
| `gameplay.py`  | A lógica de uma fase: rotas, pontinhos, bloqueios, cartéis, violência e o efeito balão. |
| `phases.py`    | Os dados de cada fase (lugares, rotas, custos, textos, fact cards). **Edite aqui.** |
| `settings.py`  | Cores, tempos das telas e regras gerais (violência, bloqueio militar). |
| `ui.py`        | Funções de desenho reaproveitadas (texto, medidor, botão, linha tracejada). |

## Onde ajustar o quê

- **Textos dos fact cards e das fases**: `phases.py` (`"fact"`, `"intro"`, `"title"`, `"hint"`).
- **Custos das rotas e dos cartéis**: `phases.py` (`"cost"`).
- **Força do efeito balão**: `phases.py`, em `"reroute_delay"` (segundos até o
  tráfico voltar) e `"reroute_efficiency"` (quanto volta: 0.85 = 85%).
- **Violência e bloqueio militar**: `settings.py` (`VIOLENCE_...` e `MILITARY_...`).
- **Duração das telas**: `settings.py` (`..._DURATION`) e `"duration"` em cada fase.

## Versão web (celular)

- Endereço: https://mgioseffileall.github.io/balloon-effect/
- `qr.png` tem o QR code desse endereço (1470x1470 px, cerca de 12 cm a 300 dpi).
- O mesmo `main.py` roda no computador e no navegador: o laço principal é
  `async` e chama `await asyncio.sleep(0)` a cada quadro, o que a versão web
  (pygbag) exige e no computador não muda nada.
- No celular: toque funciona como clique, com área de toque maior nas rotas,
  botões e cartéis (`ROUTE_TOUCH_DISTANCE` e `TOUCH_PADDING` em `settings.py`).
  Com o celular em pé aparece "Rotate your phone to play".

### Como atualizar o site depois de mudar o jogo

Na pasta `Desktop` (a pasta ACIMA de `balloon-effect`), gere o build:
```bash
python -m pygbag --build balloon-effect
```
(No Windows, rode antes `set PYTHONUTF8=1`, porque o pygbag tropeça nos acentos.)
Depois copie o conteúdo de `balloon-effect/build/web` para o repositório
`mgioseffileall/balloon-effect` no GitHub (branch `main`) e envie com `git push`.
