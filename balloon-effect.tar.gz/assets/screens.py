# screens.py
# As TELAS do jogo. Cada tela é uma classe com três métodos:
#   handle_event(event) -> reage a cliques
#   update(dt)          -> avança o tempo (dt = segundos desde o último quadro)
#   draw(surface)       -> desenha tudo
# O main.py só chama esses três métodos na tela atual. Para trocar de tela,
# a tela chama game.change_state("nome"). Isso é a "máquina de estados".
#
# FORMATO EM PÉ (celular): cada tela tem um método _draw_portrait com a
# arrumação vertical. O código do formato deitado (notebook) não mudou.

import random
import sys

import pygame

import mapview
import settings
import ui
from gameplay import PhaseSimulation
from phases import PHASES


class Screen:
    """Classe base: define o "formato" que toda tela segue."""

    def __init__(self, game):
        self.game = game
        self.fonts = game.fonts

    def handle_event(self, event):
        pass

    def update(self, dt):
        pass

    def draw(self, surface):
        pass


def draw_pill(surface, text, font, color, center):
    """Texto com um fundo escuro arredondado, para ler bem por cima do mapa."""
    image = font.render(text, True, color)
    box = image.get_rect(center=center).inflate(28, 12)
    pygame.draw.rect(surface, settings.HEADER_BG, box, border_radius=box.height // 2)
    surface.blit(image, image.get_rect(center=box.center))


def dim_overlay(surface, alpha):
    """Escurece a tela inteira (usado atrás de cartões e títulos)."""
    shade = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
    shade.fill((*settings.HEADER_BG, alpha))
    surface.blit(shade, (0, 0))


# ======================================================================
# TELA INICIAL
# ======================================================================
class TitleScreen(Screen):
    """Tela de espera da mesa de exposição. Atrás do título roda um
    "mapa de demonstração": o computador bloqueia rotas sozinho e o
    visitante já vê o efeito balão acontecendo antes de jogar."""

    def __init__(self, game):
        super().__init__(game)
        start_y = 830 if settings.PORTRAIT else 480
        self.start_button = ui.Button("START", (settings.WIDTH // 2, start_y), (280, 76))
        self.demo = self._new_demo()
        self.demo_timer = 3.0

    def _new_demo(self):
        sim = PhaseSimulation(PHASES[0])
        sim.budget = 999  # a demonstração nunca fica sem dinheiro
        return sim

    def handle_event(self, event):
        if self.start_button.is_clicked(event):
            self.game.start_new_run()

    def update(self, dt):
        self.demo.update(dt)
        self.demo.events.clear()
        self.demo_timer -= dt
        if self.demo_timer <= 0:
            open_routes = [r for r in self.demo.routes if r.is_open]
            if open_routes:
                self.demo.block(random.choice(open_routes))
                self.demo_timer = 6.0
            elif not self.demo.pending_reroutes:
                # Tudo bloqueado: recomeça a demonstração do zero.
                self.demo = self._new_demo()
                self.demo_timer = 3.0

    def draw(self, surface):
        surface.fill(settings.BG)
        mapview.draw_map(surface, self.demo, self.fonts)
        dim_overlay(surface, 222)
        if settings.PORTRAIT:
            self._draw_portrait(surface)
            return

        cx = settings.WIDTH // 2
        ui.draw_text(surface, "GLOBAL DAY 2026  ·  THE AMERICAS", self.fonts["small"], settings.ACCENT, (cx, 120))
        ui.draw_text(surface, "The Balloon Effect", self.fonts["huge"], settings.TEXT, (cx, 210))
        ui.draw_text(surface, "You are the US government.", self.fonts["medium"], settings.TEXT, (cx, 320))
        ui.draw_text(surface, "Stop the drugs from reaching your country.",
                     self.fonts["medium"], settings.TEXT, (cx, 360))
        self.start_button.draw(surface, self.fonts["big"])
        controls = "tap or click" if sys.platform == "emscripten" else "mouse only"
        ui.draw_text(surface, f"4 eras  ·  about 3 minutes  ·  {controls}",
                     self.fonts["small"], settings.TEXT_DIM, (cx, 560))
        ui.draw_text(surface, settings.DISCLAIMER, self.fonts["small"], settings.TEXT_DIM,
                     (cx, settings.HEIGHT - 34))

    def _draw_portrait(self, surface):
        f = self.fonts
        cx = settings.WIDTH // 2
        width = settings.WIDTH - 60
        ui.draw_text(surface, "GLOBAL DAY 2026  ·  THE AMERICAS", f["small"], settings.ACCENT, (cx, 300))
        # O título não cabe numa linha só na tela em pé: vai em duas.
        ui.draw_text(surface, "The Balloon", f["huge"], settings.TEXT, (cx, 400))
        ui.draw_text(surface, "Effect", f["huge"], settings.TEXT, (cx, 495))
        y = ui.draw_wrapped(surface, "You are the US government.", f["medium"], settings.TEXT, cx, 590, width)
        ui.draw_wrapped(surface, "Stop the drugs from reaching your country.", f["medium"], settings.TEXT,
                        cx, y + 4, width)
        self.start_button.draw(surface, f["big"])
        controls = "tap or click" if sys.platform == "emscripten" else "mouse only"
        ui.draw_text(surface, f"4 eras  ·  about 3 minutes  ·  {controls}", f["small"], settings.TEXT_DIM,
                     (cx, 930))
        ui.draw_wrapped(surface, settings.DISCLAIMER, f["small"], settings.TEXT_DIM, cx, 1170, width)


# ======================================================================
# FASE JOGÁVEL
# ======================================================================
class PlayingScreen(Screen):

    def __init__(self, game, phase_index=0):
        super().__init__(game)
        self.phase_index = phase_index
        self.phase = PHASES[phase_index]
        # Toda a lógica fica em PhaseSimulation; esta tela só desenha
        # e repassa os cliques. A violência vem acumulada das fases anteriores.
        self.sim = PhaseSimulation(self.phase, violence=game.run["violence"])
        self.effects = mapview.Effects()

        # Cartão de abertura: enquanto ele aparece, o tempo da fase não corre.
        self.intro_time = settings.PHASE_INTRO_DURATION

        self.hovered_route = None
        self.hovered_cartel = None

        # Tempo restante do aviso "Not enough budget". Clicar de novo só
        # reinicia este tempo: o aviso nunca se repete nem empilha.
        self.budget_warning_time = 0.0

        # Botões POLICE / MILITARY (só nas fases com "military": True).
        self.military = False
        self.mode_buttons = []
        if self.phase.get("military"):
            if settings.PORTRAIT:
                # Em pé: os dois botões lado a lado, centralizados embaixo.
                police_pos, military_pos, size = (235, 1228), (485, 1228), (230, 60)
            else:
                police_pos, military_pos, size = (112, 678), (304, 678), (180, 50)
            self.police_button = ui.Button("POLICE", police_pos, size, color=(50, 95, 170))
            self.military_button = ui.Button("MILITARY", military_pos, size, color=settings.MILITARY)
            self.mode_buttons = [self.police_button, self.military_button]
            self._sync_mode_buttons()

    def _sync_mode_buttons(self):
        self.police_button.selected = not self.military
        self.military_button.selected = self.military

    # ---------- Eventos ----------

    def handle_event(self, event):
        if event.type != pygame.MOUSEBUTTONDOWN or event.button != 1:
            return
        if self.intro_time > 0:
            self.intro_time = 0  # clique pula o cartão de abertura
            return

        if self.mode_buttons:
            if self.police_button.is_clicked(event):
                self.military = False
                self._sync_mode_buttons()
                return
            if self.military_button.is_clicked(event):
                self.military = True
                self._sync_mode_buttons()
                return

        # Cartel tem prioridade sobre rota (as rotas começam dentro da caixa dele).
        touch = getattr(event, "touch", False)
        cartel = self.sim.cartel_at(event.pos, touch)
        if cartel is not None:
            self._feedback(event.pos, self.sim.take_down(cartel), cartel.cost)
            return
        route = self.sim.route_at(event.pos, touch)
        if route is not None:
            self._feedback(event.pos, self.sim.block(route, self.military), route.cost)

    def _feedback(self, pos, success, cost):
        """Deu certo: o custo sobe do ponto do clique ("-$2.0B").
        Faltou dinheiro: liga o aviso na barra de mensagens lá embaixo."""
        if success:
            self.effects.add("float", pos, f"-${cost:.1f}B", settings.ACCENT)
        else:
            self.budget_warning_time = settings.BUDGET_WARNING_DURATION

    # ---------- Atualização ----------

    def update(self, dt):
        self.effects.update(dt)
        self.budget_warning_time = max(0.0, self.budget_warning_time - dt)
        if self.intro_time > 0:
            self.intro_time -= dt
            return

        # Depois do primeiro desvio, a simulação inteira (relógio, pontinhos,
        # fluxos, violência) recebe o dobro do tempo a cada quadro.
        speed = settings.FAST_FORWARD_SPEED if self.sim.fast_forward else 1.0
        self.sim.update(dt * speed)
        # Transforma os acontecimentos da simulação em animações.
        for kind, pos in self.sim.events:
            self.effects.add("burst" if kind == "seized" else "pulse", pos)
        self.sim.events.clear()

        mouse = pygame.mouse.get_pos()
        self.hovered_cartel = self.sim.cartel_at(mouse)
        self.hovered_route = None if self.hovered_cartel else self.sim.route_at(mouse)

        if self.sim.finished:
            self.game.finish_phase(self.phase_index, self.sim)

    # ---------- Desenho ----------

    def draw(self, surface):
        surface.fill(settings.BG)
        mapview.draw_map(surface, self.sim, self.fonts, self.hovered_route,
                         self.hovered_cartel, self.military)
        self.effects.draw(surface, self.fonts)
        self._draw_header(surface)
        self._draw_notices(surface)
        for b in self.mode_buttons:
            b.draw(surface, self.fonts["medium"])
        if self.intro_time > 0:
            self._draw_intro(surface)
        elif not self.game.last_input_touch:
            # No celular não há "passar o mouse por cima": sem balão.
            self._draw_tooltip(surface)

    def _draw_header(self, surface):
        f = self.fonts
        pygame.draw.rect(surface, settings.HEADER_BG, (0, 0, settings.WIDTH, settings.HEADER_HEIGHT))
        if settings.PORTRAIT:
            self._draw_header_portrait(surface)
            return

        ui.draw_text(surface, self.phase["title"], f["medium"], settings.TEXT, (22, 32), "midleft")
        ui.draw_text(surface, self.phase["hint"], f["tiny"], settings.ACCENT, (22, 64), "midleft")

        # Os 3 medidores
        ui.draw_meter(surface, f, (400, 44, 130, 24), "Drugs reaching US",
                      self.sim.drugs_reaching(), settings.METER_DRUGS)
        money = self.game.run["money_spent"] + self.sim.money_spent
        ui.draw_meter(surface, f, (608, 44, 130, 24), "Money spent",
                      money / settings.MONEY_METER_MAX, settings.METER_MONEY, f"${money:.1f}B")
        violence = self.sim.violence / settings.VIOLENCE_MAX
        violence_color = ui.mix(settings.METER_VIOLENCE_LOW, settings.METER_VIOLENCE_HIGH, violence)
        ui.draw_meter(surface, f, (826, 44, 130, 24), "Violence", violence, violence_color)

        # Orçamento e tempo
        ui.draw_text(surface, "Budget", f["tiny"], settings.TEXT_DIM, (1030, 39), "bottomleft")
        budget_color = settings.TEXT if not self.sim.out_of_budget() else settings.METER_DRUGS
        ui.draw_text(surface, f"${self.sim.budget:.1f}B", f["header"], budget_color, (1030, 42), "topleft")

        seconds = int(self.sim.time_left + 0.999)  # arredonda para cima: 0:01 até o fim
        time_color = settings.TEXT if seconds > 5 else settings.ACCENT
        ui.draw_text(surface, "Time", f["tiny"], settings.TEXT_DIM, (1170, 39), "bottomleft")
        if self.sim.fast_forward:
            ui.draw_text(surface, f"{settings.FAST_FORWARD_SPEED:g}x", f["tiny"], settings.ACCENT,
                         (1212, 39), "bottomleft")
        ui.draw_text(surface, f"0:{seconds:02d}", f["header"], time_color, (1170, 42), "topleft")

    def _draw_header_portrait(self, surface):
        """Topo em pé, em 3 linhas:
        1) título da fase ......................... tempo
        2) dica da fase ........................... orçamento
        3) os 3 medidores lado a lado"""
        f = self.fonts
        right = settings.WIDTH - 20
        title_font = ui.fit_font(f, self.phase["title"], 430)
        ui.draw_text(surface, self.phase["title"], title_font, settings.TEXT, (20, 32), "midleft")
        ui.draw_text(surface, self.phase["hint"], f["tiny"], settings.ACCENT, (20, 72), "midleft")

        seconds = int(self.sim.time_left + 0.999)
        time_color = settings.TEXT if seconds > 5 else settings.ACCENT
        rect = ui.draw_text(surface, f"0:{seconds:02d}", f["header"], time_color, (right, 8), "topright")
        label = f"Time {settings.FAST_FORWARD_SPEED:g}x" if self.sim.fast_forward else "Time"
        label_color = settings.ACCENT if self.sim.fast_forward else settings.TEXT_DIM
        ui.draw_text(surface, label, f["tiny"], label_color, (rect.left - 10, rect.centery), "midright")

        budget_color = settings.TEXT if not self.sim.out_of_budget() else settings.METER_DRUGS
        rect = ui.draw_text(surface, f"${self.sim.budget:.1f}B", f["header"], budget_color, (right, 56), "topright")
        ui.draw_text(surface, "Budget", f["tiny"], settings.TEXT_DIM, (rect.left - 10, rect.centery), "midright")

        y = 124
        ui.draw_meter(surface, f, (20, y, 115, 24), "Drugs reaching US",
                      self.sim.drugs_reaching(), settings.METER_DRUGS)
        money = self.game.run["money_spent"] + self.sim.money_spent
        ui.draw_meter(surface, f, (255, y, 115, 24), "Money spent",
                      money / settings.MONEY_METER_MAX, settings.METER_MONEY, f"${money:.1f}B")
        violence = self.sim.violence / settings.VIOLENCE_MAX
        violence_color = ui.mix(settings.METER_VIOLENCE_LOW, settings.METER_VIOLENCE_HIGH, violence)
        ui.draw_meter(surface, f, (490, y, 115, 24), "Violence", violence, violence_color)

    def _current_message(self):
        """BARRA DE MENSAGENS: um único lugar, uma única mensagem por vez.
        Várias coisas podem querer aparecer ao mesmo tempo; esta lista,
        em ordem de prioridade, decide qual ganha. Retorna (texto, cor)
        ou None se não houver nada para mostrar."""
        # 1) Os traficantes reagiram: é o momento do efeito balão.
        if self.sim.notice_time > 0:
            return self.sim.notice, settings.TEXT
        # 2) O jogador clicou sem dinheiro suficiente.
        if self.budget_warning_time > 0:
            return "Not enough budget", settings.ROUTE_HOVER_MILITARY
        # 3) Contagem regressiva: mostra que o bloqueio é TEMPORÁRIO.
        if self.sim.pending_reroutes:
            seconds = min(item["time"] for item in self.sim.pending_reroutes)
            return f"Traffickers are looking for a new route... {int(seconds + 0.999)}s", settings.ROUTE_HOVER
        # 4) Acabou o dinheiro: só resta assistir.
        if self.sim.out_of_budget():
            return "Out of budget. Watch what happens...", settings.TEXT_DIM
        return None

    def _draw_notices(self, surface):
        message = self._current_message()
        if message is None:
            return
        text, color = message
        # Com os botões POLICE/MILITARY na esquerda, a mensagem anda um
        # pouco para a direita para não ficar por cima deles.
        if settings.PORTRAIT:
            # Em pé: a mensagem fica acima dos botões, numa fonte que caiba.
            font = ui.fit_font(self.fonts, text, settings.WIDTH - 60)
            draw_pill(surface, text, font, color, (settings.WIDTH // 2, 1160))
            return
        cx = settings.WIDTH // 2 + (120 if self.mode_buttons else 0)
        draw_pill(surface, text, self.fonts["medium"], color, (cx, settings.HEIGHT - 40))

    def _draw_tooltip(self, surface):
        """Balão perto do cursor: o que o clique faz e quanto custa.
        Se não der para pagar, o texto fica apagado (o aviso de falta de
        dinheiro aparece só na barra de mensagens, para não repetir)."""
        if self.hovered_cartel is not None:
            c = self.hovered_cartel
            text = f"Take down the {c.name}: ${c.cost:.1f}B"
            cost = c.cost
        elif self.hovered_route is not None:
            r = self.hovered_route
            kind = "Military block" if self.military else "Block"
            text = f"{kind}: {r.name}  ${r.cost:.1f}B"
            cost = r.cost
        else:
            return
        color = settings.TEXT if self.sim.budget >= cost else settings.TEXT_DIM
        mx, my = pygame.mouse.get_pos()
        image = self.fonts["small"].render(text, True, color)
        box = image.get_rect(topleft=(mx + 18, my + 18)).inflate(18, 12)
        box.clamp_ip(surface.get_rect())  # não deixa o balão sair da tela
        pygame.draw.rect(surface, settings.HEADER_BG, box, border_radius=6)
        pygame.draw.rect(surface, settings.TEXT_DIM, box, 1, border_radius=6)
        surface.blit(image, image.get_rect(center=box.center))

    def _draw_intro(self, surface):
        """Cartão de abertura da fase, por cima do mapa escurecido."""
        dim_overlay(surface, 190)
        if settings.PORTRAIT:
            self._draw_intro_portrait(surface)
            return
        cx = settings.WIDTH // 2
        card = pygame.Rect(0, 0, 820, 360)
        card.center = (cx, 400)
        pygame.draw.rect(surface, settings.PANEL, card, border_radius=18)
        pygame.draw.rect(surface, settings.ACCENT, card, 2, border_radius=18)

        ui.draw_text(surface, f"ERA {self.phase_index + 1} OF {len(PHASES)}", self.fonts["small"],
                     settings.ACCENT, (cx, card.y + 40))
        ui.draw_text(surface, self.phase["title"], self.fonts["big"], settings.TEXT, (cx, card.y + 95))
        y = card.y + 160
        for line in self.phase["intro"]:
            ui.draw_text(surface, line, self.fonts["medium"], settings.TEXT, (cx, y))
            y += 40
        ui.draw_text(surface, f"Starting in {self.intro_time:.0f}...  (click to start now)",
                     self.fonts["small"], settings.TEXT_DIM, (cx, card.bottom - 32))

    def _draw_intro_portrait(self, surface):
        f = self.fonts
        cx = settings.WIDTH // 2
        width = settings.WIDTH - 60
        inner = width - 60
        # Primeiro mede a altura do texto, para o cartão ter o tamanho certo.
        title_h = len(ui.wrap_text(self.phase["title"], f["big"], inner)) * f["big"].get_linesize()
        body_h = sum(len(ui.wrap_text(line, f["medium"], inner)) for line in self.phase["intro"]) \
            * f["medium"].get_linesize()
        card = pygame.Rect(0, 0, width, 90 + title_h + 30 + body_h + 130)
        card.center = (cx, settings.HEIGHT // 2)
        pygame.draw.rect(surface, settings.PANEL, card, border_radius=18)
        pygame.draw.rect(surface, settings.ACCENT, card, 2, border_radius=18)

        ui.draw_text(surface, f"ERA {self.phase_index + 1} OF {len(PHASES)}", f["small"],
                     settings.ACCENT, (cx, card.y + 50))
        y = ui.draw_wrapped(surface, self.phase["title"], f["big"], settings.TEXT, cx, card.y + 90, inner)
        y += 30
        for line in self.phase["intro"]:
            y = ui.draw_wrapped(surface, line, f["medium"], settings.TEXT, cx, y, inner)
        ui.draw_text(surface, f"Starting in {self.intro_time:.0f}...", f["small"], settings.TEXT_DIM,
                     (cx, card.bottom - 80))
        ui.draw_text(surface, "(tap to start now)", f["small"], settings.TEXT_DIM, (cx, card.bottom - 42))


# ======================================================================
# FACT CARD (entre as fases)
# ======================================================================
class FactCardScreen(Screen):
    """Fato histórico real entre as fases. Fica na tela até o visitante
    clicar em OK, para cada um ler no seu ritmo. (Se ninguém clicar, o
    reset por inatividade do main.py volta para a tela inicial.)"""

    # Cliques nos primeiros instantes são ignorados: quem estava clicando
    # rápido nas rotas no fim da fase não pula o card sem querer.
    CLICK_DELAY = 1.0

    def __init__(self, game, phase_index):
        super().__init__(game)
        self.phase_index = phase_index
        self.phase = PHASES[phase_index]
        self.age = 0.0
        if settings.PORTRAIT:
            # Em pé, o cartão é mais alto; o botão fica logo abaixo dele.
            f = self.fonts
            inner = settings.WIDTH - 120
            text_h = (len(ui.wrap_text("What really happened", f["big"], inner))
                      + len(ui.wrap_text(self.phase["fact"], f["big"], inner))) * f["big"].get_linesize()
            self.card = pygame.Rect(0, 0, settings.WIDTH - 60, 90 + text_h + 40 + 60)
            # Cartão + botão (64) + "Next" (~60) centralizados na altura da tela.
            total = self.card.height + 50 + 64 + 60
            self.card.midtop = (settings.WIDTH // 2, max(60, (settings.HEIGHT - total) // 2 - 40))
            ok_y = self.card.bottom + 50 + 32
        else:
            ok_y = 610
        self.ok_button = ui.Button("OK", (settings.WIDTH // 2, ok_y), (220, 64))

    def handle_event(self, event):
        if self.age >= self.CLICK_DELAY and self.ok_button.is_clicked(event):
            self.game.go_to_phase(self.phase_index + 1)

    def update(self, dt):
        self.age += dt

    def draw(self, surface):
        surface.fill(settings.BG)
        if settings.PORTRAIT:
            self._draw_portrait(surface)
            return
        cx = settings.WIDTH // 2

        card = pygame.Rect(0, 0, 960, 420)
        card.center = (cx, 330)
        pygame.draw.rect(surface, settings.PANEL, card, border_radius=20)
        pygame.draw.rect(surface, settings.ACCENT, card, 2, border_radius=20)

        ui.draw_text(surface, f"{self.phase['era']}  ·  FACT CARD", self.fonts["small"],
                     settings.ACCENT, (cx, card.y + 45))
        ui.draw_text(surface, "What really happened", self.fonts["big"], settings.TEXT, (cx, card.y + 105))

        lines = ui.wrap_text(self.phase["fact"], self.fonts["big"], card.width - 120)
        y = card.y + 190
        for line in lines:
            ui.draw_text(surface, line, self.fonts["big"], settings.TEXT, (cx, y))
            y += 52

        # O botão só aparece depois do pequeno atraso, junto com o clique.
        if self.age >= self.CLICK_DELAY:
            self.ok_button.draw(surface, self.fonts["big"])

        next_index = self.phase_index + 1
        if next_index < len(PHASES):
            next_text = f"Next: {PHASES[next_index]['title']}"
        else:
            next_text = "Next: Your results"   # depois da última fase vem a tela final
        ui.draw_text(surface, next_text, self.fonts["small"], settings.TEXT_DIM, (cx, 665))
        ui.draw_text(surface, settings.DISCLAIMER, self.fonts["tiny"], settings.TEXT_DIM,
                     (cx, settings.HEIGHT - 22))

    def _next_text(self):
        next_index = self.phase_index + 1
        if next_index < len(PHASES):
            return f"Next: {PHASES[next_index]['title']}"
        return "Next: Your results"

    def _draw_portrait(self, surface):
        f = self.fonts
        cx = settings.WIDTH // 2
        card = self.card
        inner = card.width - 60
        pygame.draw.rect(surface, settings.PANEL, card, border_radius=20)
        pygame.draw.rect(surface, settings.ACCENT, card, 2, border_radius=20)

        ui.draw_text(surface, f"{self.phase['era']}  ·  FACT CARD", f["small"], settings.ACCENT,
                     (cx, card.y + 50))
        y = ui.draw_wrapped(surface, "What really happened", f["big"], settings.TEXT, cx, card.y + 90, inner)
        ui.draw_wrapped(surface, self.phase["fact"], f["big"], settings.TEXT, cx, y + 40, inner)

        if self.age >= self.CLICK_DELAY:
            self.ok_button.draw(surface, f["big"])
        ui.draw_wrapped(surface, self._next_text(), f["small"], settings.TEXT_DIM, cx,
                        self.ok_button.rect.bottom + 20, card.width)
        ui.draw_wrapped(surface, settings.DISCLAIMER, f["tiny"], settings.TEXT_DIM, cx,
                        settings.HEIGHT - 70, card.width)


# ======================================================================
# TELA FINAL
# ======================================================================
def violence_label(value):
    """Transforma o número da violência (0 a 100) numa palavra."""
    if value < 25:
        return "Low"
    if value < 50:
        return "Moderate"
    if value < 75:
        return "High"
    return "Extreme"


class EndingScreen(Screen):

    def __init__(self, game):
        super().__init__(game)
        self.time_left = settings.ENDING_DURATION

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            self.game.change_state("title")

    def update(self, dt):
        self.time_left -= dt
        if self.time_left <= 0:
            self.game.change_state("title")

    def draw(self, surface):
        surface.fill(settings.BG)
        run = self.game.run
        f = self.fonts
        cx = settings.WIDTH // 2

        start, end = run["drugs_start"], run["drugs_end"]
        drop = round((start - end) / start * 100) if start else 0
        drop_text = f"down only {drop}%" if drop > 0 else "no drop at all"

        rows = [("Routes blocked", f"{run['routes_blocked']}")]
        if run["cartels_down"]:
            rows.append(("Cartels taken down", f"{run['cartels_down']}"))
        rows += [
            ("Money spent", f"${run['money_spent']:.1f} billion"),
            ("Drugs reaching the US", f"from {start * 100:.0f}% to {end * 100:.0f}%  ({drop_text})"),
            ("Violence", f"{run['violence']:.0f}%  ({violence_label(run['violence'])})"),
        ]
        if settings.PORTRAIT:
            self._draw_portrait(surface, rows)
            return

        ui.draw_text(surface, "Your results", f["big"], settings.TEXT, (cx, 80))
        panel = pygame.Rect(0, 0, 820, 50 + 48 * len(rows))
        panel.midtop = (cx, 130)
        pygame.draw.rect(surface, settings.PANEL, panel, border_radius=16)
        y = panel.y + 48
        for label, value in rows:
            ui.draw_text(surface, label, f["medium"], settings.TEXT_DIM, (panel.x + 40, y), "midleft")
            ui.draw_text(surface, value, f["medium"], settings.TEXT, (panel.right - 40, y), "midright")
            y += 48

        ui.draw_text(surface, "Every route you closed, a new one opened.",
                     f["big"], settings.ACCENT, (cx, panel.bottom + 70))
        ui.draw_text(surface, "This is the balloon effect.",
                     f["big"], settings.ACCENT, (cx, panel.bottom + 125))

        ui.draw_text(surface, f"Click to return to the start  ·  back to start in {max(0, self.time_left):.0f}s",
                     f["small"], settings.TEXT_DIM, (cx, settings.HEIGHT - 70))
        ui.draw_text(surface, settings.DISCLAIMER, f["small"], settings.TEXT_DIM,
                     (cx, settings.HEIGHT - 34))

    def _draw_portrait(self, surface, rows):
        """Resultados em pé: cada item ocupa duas linhas (nome e valor)."""
        f = self.fonts
        cx = settings.WIDTH // 2
        width = settings.WIDTH - 60
        ui.draw_text(surface, "Your results", f["big"], settings.TEXT, (cx, 110))

        row_h = 86
        panel = pygame.Rect(0, 0, width, 30 + row_h * len(rows))
        panel.midtop = (cx, 170)
        pygame.draw.rect(surface, settings.PANEL, panel, border_radius=16)
        y = panel.y + 40
        for label, value in rows:
            ui.draw_text(surface, label, f["small"], settings.TEXT_DIM, (cx, y))
            value_font = ui.fit_font(f, value, panel.width - 40, ("medium", "small"))
            ui.draw_text(surface, value, value_font, settings.TEXT, (cx, y + 36))
            y += row_h

        y = ui.draw_wrapped(surface, "Every route you closed, a new one opened.", f["big"], settings.ACCENT,
                            cx, panel.bottom + 50, width)
        ui.draw_wrapped(surface, "This is the balloon effect.", f["big"], settings.ACCENT, cx, y + 10, width)

        ui.draw_wrapped(surface, f"Tap to return to the start  ·  back to start in {max(0, self.time_left):.0f}s",
                        f["small"], settings.TEXT_DIM, cx, settings.HEIGHT - 200, width)
        ui.draw_wrapped(surface, settings.DISCLAIMER, f["small"], settings.TEXT_DIM, cx,
                        settings.HEIGHT - 110, width)
