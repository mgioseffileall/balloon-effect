# phases.py
# DADOS de cada fase. Aqui quase não tem lógica: só textos e números.
# A ideia é poder editar nomes, posições, custos e os fact cards
# sem mexer no resto do código.
#
# Como ler cada fase:
#   "era", "title", "hint": textos do topo da tela.
#   "intro": linhas do cartão de abertura da fase.
#   "duration": segundos de fase.  "budget": orçamento inicial (bilhões).
#   "reroute_delay": segundos até os traficantes acharem outra rota.
#   "reroute_efficiency": fração da droga desviada que volta a chegar.
#   "ramp_speed": quão rápido o fluxo cresce numa rota nova (por segundo).
#   "shipments_per_second": pontinhos criados por segundo com 100% de fluxo.
#   "military": True = o jogador pode escolher bloqueio MILITAR.
#   "prefer_new_routes": True = cada bloqueio faz surgir uma rota NOVA.
#
#   "places": os retângulos do mapa. "pos" é o CENTRO (x, y) na tela de
#       1280x720. "kind" define a cor: "source" (produtor), "transit"
#       (passagem), "destination" (EUA), "cartel" ou "group".
#       "hidden": True = só aparece mais tarde (grupos de um cartel caído).
#   "regions": áreas de fundo com nome (ex.: o território da Colômbia).
#   "links": linhas tracejadas só decorativas (não dá para bloquear).
#   "routes": as linhas clicáveis.
#       "path": pontos por onde a rota passa. Pode ser o nome de um lugar
#               (ex.: "mexico") ou uma coordenada solta (x, y), para fazer
#               curvas ou chegar num ponto específico da caixa dos EUA.
#       "cost": quanto custa bloquear, em bilhões de dólares.
#       "flow": fração da droga que passa por ela no início (0 a 1).
#               A soma das rotas visíveis deve dar 1.0 (= 100%).
#       "hidden": True = rota reserva, que os traficantes abrem depois.
#       "group": rota que só aparece quando um cartel se divide.
#       "thin": True = rota pequena (linha mais fina).
#       "block_at": onde fica o X (fração do caminho; padrão 0.75).
#   "cartels": cartéis que o jogador pode derrubar (fase 2).
#   "labels": textos decorativos no mapa (oceanos etc.).
#   "fact": texto do fact card mostrado DEPOIS da fase (None = sem card).


# ----------------------------------------------------------------------
# Fase 4: as rotas de fentanil são muitas e parecidas, então em vez de
# escrever uma por uma, este pequeno ajudante gera a lista.
# Mude os números abaixo para ter mais ou menos rotas.
# ----------------------------------------------------------------------
FENTANYL_ROUTE_COUNT = 16        # total de rotas (metade começa escondida)
FENTANYL_ROUTE_COST = 1.0
FENTANYL_ROUTE_NAMES = [
    "Car trunk", "Mail package", "Backpack", "Truck cargo",
    "Small boat", "Tunnel", "Drone", "Courier",
]


def _fentanyl_routes():
    routes = []
    visible = FENTANYL_ROUTE_COUNT // 2
    for i in range(FENTANYL_ROUTE_COUNT):
        # Saem do topo da caixa do México e se espalham pela fronteira.
        start = (560 + i * 160 / (FENTANYL_ROUTE_COUNT - 1), 545)
        end = (190 + i * 900 / (FENTANYL_ROUTE_COUNT - 1), 172)
        wiggle = ((i * 37) % 5 - 2) * 14   # pequena "torção" para não parecerem iguais
        middle = ((start[0] + end[0]) / 2 + wiggle, 370 + wiggle)
        routes.append({
            "id": f"tiny{i}",
            "name": FENTANYL_ROUTE_NAMES[i % len(FENTANYL_ROUTE_NAMES)],
            "path": [start, middle, end],
            "cost": FENTANYL_ROUTE_COST,
            "flow": 1.0 / visible if i % 2 == 0 else 0.0,
            "hidden": i % 2 == 1,   # as de índice ímpar começam escondidas
            "thin": True,
        })
    # Pacotes pelo correio, direto da China: também começam escondidos.
    routes.append({"id": "mail1", "name": "Mail from China", "thin": True, "hidden": True,
                   "path": ["china", (100, 400), (160, 172)], "cost": FENTANYL_ROUTE_COST, "flow": 0.0})
    routes.append({"id": "mail2", "name": "Online order", "thin": True, "hidden": True,
                   "path": ["china", (40, 520), (40, 240), (150, 160)], "cost": FENTANYL_ROUTE_COST, "flow": 0.0})
    return routes


PHASES = [
    # ==================================================================
    # FASE 1 — anos 1980: tutorial com 2 rotas
    # ==================================================================
    {
        "id": "1980s",
        "era": "1980s",
        "title": "1980s: The Cocaine Boom",
        "hint": "Click a route to block it.",
        "intro": [
            "Cocaine flows from Colombia to Miami.",
            "Click a route to block it. You have $5B.",
        ],
        "duration": 33,
        "budget": 5.0,
        "reroute_delay": 4.0,
        "reroute_efficiency": 0.85,
        "ramp_speed": 0.2,
        "shipments_per_second": 5,

        "places": {
            "usa":       {"name": "USA (Miami)", "pos": (640, 160), "size": (260, 64), "kind": "destination"},
            "mexico":    {"name": "Mexico",      "pos": (380, 370), "size": (180, 56), "kind": "transit"},
            "caribbean": {"name": "Caribbean",   "pos": (900, 370), "size": (180, 56), "kind": "transit"},
            "colombia":  {"name": "Colombia",    "pos": (640, 570), "size": (200, 64), "kind": "source"},
        },

        "routes": [
            {"id": "caribbean", "name": "Caribbean route",
             "path": ["colombia", "caribbean", "usa"], "cost": 2.0, "flow": 0.6},
            {"id": "mexico", "name": "Mexico route",
             "path": ["colombia", "mexico", "usa"], "cost": 1.5, "flow": 0.4},
            # Rota reserva: só aparece se as duas de cima forem bloqueadas.
            {"id": "pacific", "name": "Pacific route",
             "path": ["colombia", (300, 620), (150, 430), (240, 200), "usa"],
             "cost": 2.0, "flow": 0.0, "hidden": True},
        ],

        "labels": [
            {"text": "Caribbean Sea", "pos": (1060, 520)},
            {"text": "Pacific Ocean", "pos": (120, 580)},
            {"text": "Gulf of Mexico", "pos": (640, 300)},
        ],

        "fact": (
            "In 1982, the South Florida Task Force shut down much of the "
            "Caribbean route to Miami. Trafficking moved to Mexico."
        ),
    },

    # ==================================================================
    # FASE 2 — anos 1990: derrubar os grandes cartéis colombianos
    # ==================================================================
    {
        "id": "1990s",
        "era": "1990s",
        "title": "1990s: Cartel Wars",
        "hint": "NEW: click a cartel to take it down.",
        "intro": [
            "Two giant cartels control Colombia's cocaine.",
            "NEW: click a cartel to take it down.",
        ],
        "duration": 33,
        "budget": 5.0,
        "reroute_delay": 4.0,
        "reroute_efficiency": 0.9,
        "ramp_speed": 0.2,
        "shipments_per_second": 6,

        "regions": [
            {"name": "COLOMBIA", "rect": (320, 475, 640, 155)},
        ],

        "places": {
            "usa":       {"name": "USA", "pos": (640, 150), "size": (420, 60), "kind": "destination"},
            "mexico":    {"name": "Mexico", "pos": (290, 350), "size": (170, 52), "kind": "transit"},
            "caribbean": {"name": "Caribbean", "pos": (990, 350), "size": (180, 52), "kind": "transit"},
            "medellin":  {"name": "Medellín Cartel", "pos": (490, 555), "size": (230, 54), "kind": "cartel"},
            "cali":      {"name": "Cali Cartel", "pos": (800, 555), "size": (200, 54), "kind": "cartel"},
            # Grupos menores: aparecem quando o cartel cai.
            "med_a":  {"name": "Small group", "pos": (405, 535), "size": (110, 34), "kind": "group", "hidden": True},
            "med_b":  {"name": "Small group", "pos": (560, 535), "size": (110, 34), "kind": "group", "hidden": True},
            "med_c":  {"name": "Small group", "pos": (480, 598), "size": (110, 34), "kind": "group", "hidden": True},
            "cali_a": {"name": "Small group", "pos": (725, 535), "size": (110, 34), "kind": "group", "hidden": True},
            "cali_b": {"name": "Small group", "pos": (880, 535), "size": (110, 34), "kind": "group", "hidden": True},
            "cali_c": {"name": "Small group", "pos": (800, 598), "size": (110, 34), "kind": "group", "hidden": True},
        },

        "routes": [
            # Rotas dos grandes cartéis
            {"id": "med_mex", "name": "Mexico route",
             "path": ["medellin", "mexico", (470, 170)], "cost": 1.5, "flow": 0.30},
            {"id": "med_air", "name": "Air route",
             "path": ["medellin", (565, 440), (590, 170)], "cost": 1.0, "flow": 0.25},
            {"id": "cali_carib", "name": "Caribbean route",
             "path": ["cali", "caribbean", (810, 170)], "cost": 2.0, "flow": 0.45},

            # Rotas reserva
            {"id": "central", "name": "Central America route", "hidden": True,
             "path": ["medellin", (200, 570), (120, 330), (450, 160)], "cost": 1.5, "flow": 0.0},
            {"id": "venezuela", "name": "Venezuela route", "hidden": True,
             "path": ["cali", (1170, 570), (1200, 300), (845, 150)], "cost": 1.5, "flow": 0.0},

            # Rotas pequenas dos grupos que surgem quando um cartel cai
            {"id": "ma", "name": "Small group route", "group": "medellin", "hidden": True, "thin": True,
             "path": ["med_a", "mexico", (455, 172)], "cost": 1.0, "flow": 0.0},
            {"id": "mb", "name": "Small group route", "group": "medellin", "hidden": True, "thin": True,
             "path": ["med_b", (600, 420), (580, 172)], "cost": 1.0, "flow": 0.0},
            {"id": "mc", "name": "Small group route", "group": "medellin", "hidden": True, "thin": True,
             "path": ["med_c", (482, 470), (515, 172)], "cost": 1.0, "flow": 0.0},
            {"id": "ca", "name": "Small group route", "group": "cali", "hidden": True, "thin": True,
             "path": ["cali_a", (690, 420), (700, 172)], "cost": 1.0, "flow": 0.0},
            {"id": "cb", "name": "Small group route", "group": "cali", "hidden": True, "thin": True,
             "path": ["cali_b", "caribbean", (830, 172)], "cost": 1.0, "flow": 0.0},
            {"id": "cc", "name": "Small group route", "group": "cali", "hidden": True, "thin": True,
             "path": ["cali_c", (802, 470), (765, 172)], "cost": 1.0, "flow": 0.0},
        ],

        "cartels": [
            {"place": "medellin", "name": "Medellín Cartel", "cost": 2.0,
             "routes": ["med_mex", "med_air", "central"],
             "split_places": ["med_a", "med_b", "med_c"], "split_routes": ["ma", "mb", "mc"]},
            {"place": "cali", "name": "Cali Cartel", "cost": 2.0,
             "routes": ["cali_carib", "venezuela"],
             "split_places": ["cali_a", "cali_b", "cali_c"], "split_routes": ["ca", "cb", "cc"]},
        ],

        "labels": [
            {"text": "Caribbean Sea", "pos": (1010, 470)},
            {"text": "Pacific Ocean", "pos": (100, 520)},
        ],

        "fact": (
            "After the Medellín (1993) and Cali (1995) cartels fell, cocaine kept "
            "flowing — Mexican groups took control of the routes."
        ),
    },

    # ==================================================================
    # FASE 3 — anos 2000: México e o bloqueio militar
    # ==================================================================
    {
        "id": "2000s",
        "era": "2000s",
        "title": "2000s: The Mexican Front",
        "hint": "NEW: choose POLICE or MILITARY blocks.",
        "intro": [
            "Mexican cartels now move the drugs north.",
            "NEW: MILITARY blocks hold longer,",
            "but violence rises much faster.",
        ],
        "duration": 33,
        "budget": 5.0,
        "reroute_delay": 4.0,
        "reroute_efficiency": 0.85,
        "ramp_speed": 0.2,
        "shipments_per_second": 6,
        "military": True,

        "regions": [
            {"name": "MEXICO", "rect": (110, 285, 1060, 240)},
        ],

        "places": {
            "usa":      {"name": "USA", "pos": (640, 150), "size": (1000, 60), "kind": "destination"},
            "tijuana":  {"name": "Tijuana", "pos": (230, 330), "size": (150, 46), "kind": "transit"},
            "juarez":   {"name": "Ciudad Juárez", "pos": (560, 330), "size": (190, 46), "kind": "transit"},
            "laredo":   {"name": "Nuevo Laredo", "pos": (930, 330), "size": (190, 46), "kind": "transit"},
            "sinaloa":  {"name": "Sinaloa Cartel", "pos": (370, 475), "size": (210, 50), "kind": "cartel"},
            "gulf":     {"name": "Gulf Cartel", "pos": (880, 475), "size": (190, 50), "kind": "cartel"},
            "colombia": {"name": "Colombia", "pos": (620, 585), "size": (190, 50), "kind": "source"},
        },

        "links": [
            ["colombia", "sinaloa"],
            ["colombia", "gulf"],
        ],

        "routes": [
            {"id": "tij", "name": "Tijuana crossing",
             "path": ["sinaloa", "tijuana", (230, 172)], "cost": 1.5, "flow": 0.30},
            {"id": "jua", "name": "Ciudad Juárez crossing",
             "path": ["sinaloa", "juarez", (560, 172)], "cost": 2.0, "flow": 0.35},
            {"id": "lar", "name": "Nuevo Laredo crossing",
             "path": ["gulf", "laredo", (930, 172)], "cost": 1.5, "flow": 0.35},

            # Rotas reserva (na ordem em que aparecem)
            {"id": "tunnel", "name": "Tunnel under the border", "hidden": True,
             "path": ["sinaloa", (420, 380), (395, 172)], "cost": 1.0, "flow": 0.0},
            {"id": "reynosa", "name": "Reynosa crossing", "hidden": True,
             "path": ["gulf", (745, 400), (745, 172)], "cost": 1.0, "flow": 0.0},
            {"id": "sonora", "name": "Sonora desert", "hidden": True,
             "path": ["sinaloa", (90, 440), (90, 250), (160, 172)], "cost": 1.0, "flow": 0.0},
            {"id": "boat", "name": "Boats in the Gulf", "hidden": True,
             "path": ["gulf", (1200, 500), (1200, 260), (1110, 172)], "cost": 1.0, "flow": 0.0},
        ],

        "labels": [
            {"text": "Pacific Ocean", "pos": (140, 585)},
            {"text": "Gulf of Mexico", "pos": (1090, 585)},
        ],

        "fact": (
            "After Mexico launched a military offensive in late 2006, violence "
            "exploded: more than 60,000 deaths were linked to organized crime by 2012."
        ),
    },

    # ==================================================================
    # FASE 4 — anos 2020: fentanil, rotas minúsculas demais para bloquear
    # ==================================================================
    {
        "id": "2020s",
        "era": "2020s",
        "title": "2020s: Fentanyl",
        "hint": "Tiny routes everywhere. Try to block them.",
        "intro": [
            "Fentanyl is so strong that tiny packages are enough:",
            "cars, mail, backpacks, drones.",
            "Too many routes... try to block them anyway.",
        ],
        "duration": 33,
        "budget": 5.0,
        "reroute_delay": 2.5,
        "reroute_efficiency": 0.95,
        "ramp_speed": 0.25,
        "shipments_per_second": 12,
        "military": True,
        "prefer_new_routes": True,

        "places": {
            "usa":    {"name": "USA", "pos": (640, 150), "size": (1000, 60), "kind": "destination"},
            "mexico": {"name": "Mexico (labs)", "pos": (640, 565), "size": (240, 52), "kind": "transit"},
            "china":  {"name": "China & India (chemicals)", "pos": (195, 585), "size": (350, 50), "kind": "source"},
        },

        "links": [
            ["china", "mexico"],
        ],

        "routes": _fentanyl_routes(),

        "labels": [
            {"text": "chemicals by ship", "pos": (450, 612)},
        ],

        "fact": (
            "In 2024, US overdose deaths fell about 27%. Experts link part of the "
            "drop to treatment and naloxone, not only to fighting cartels."
        ),
    },
]
