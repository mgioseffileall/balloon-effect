# main.py
# Ponto de entrada do jogo. Rode com:  python3 main.py
#
# Aqui fica o "laço principal" (game loop), que roda ~60 vezes por segundo:
#   1. lê os eventos (mouse, teclado)
#   2. atualiza a tela atual
#   3. desenha a tela atual
# E também a MÁQUINA DE ESTADOS: o jogo está sempre em UMA tela
# (title, playing, fact_card ou ending), guardada em self.state.
#
# VERSÃO WEB: o mesmo arquivo roda no navegador com o pygbag. Por isso o
# laço é "async": no navegador, o jogo precisa devolver o controle à
# página a cada quadro (await asyncio.sleep(0)), senão a aba trava.
# No computador isso não muda nada.

import asyncio
import sys

import pygame

import settings
import ui
from phases import PHASES
from screens import TitleScreen, PlayingScreen, FactCardScreen, EndingScreen

# Nome do estado -> classe da tela. Para criar uma tela nova, basta
# escrever a classe em screens.py e registrá-la aqui.
# True quando o jogo está rodando no navegador (pygbag usa "emscripten").
IS_WEB = sys.platform == "emscripten"

# Dois "cliques" seguidos em menos deste tempo contam como um só.
# No celular, um toque pode chegar duas vezes (como dedo E como mouse).
DUPLICATE_CLICK_WINDOW = 0.35

STATES = {
    "title": TitleScreen,
    "playing": PlayingScreen,
    "fact_card": FactCardScreen,
    "ending": EndingScreen,
}


class Game:
    def __init__(self):
        pygame.init()
        pygame.display.set_caption(settings.TITLE)
        # SCALED: o jogo sempre "pensa" em 1280x720, e o Pygame estica a
        # imagem para caber na tela cheia. Assim as posições do mapa e dos
        # cliques continuam valendo em qualquer monitor.
        # (No navegador quem estica a imagem é a própria página.)
        flags = 0 if IS_WEB else pygame.SCALED
        self.screen = pygame.display.set_mode((settings.WIDTH, settings.HEIGHT), flags)
        self.clock = pygame.time.Clock()
        self.fonts = ui.load_fonts()
        self.running = True
        self.run = None         # estatísticas da partida atual (todas as fases)
        self.idle_time = 0.0    # segundos sem ninguém mexer no mouse
        self.state = None
        self.state_name = None
        self.state_age = 0.0    # há quanto tempo a tela atual começou (para o fade)
        self.fade = pygame.Surface((settings.WIDTH, settings.HEIGHT))
        self.fade.fill((0, 0, 0))
        self.last_click_time = -10.0
        self.last_input_touch = False  # o último clique foi um toque de dedo?
        self.wrong_orientation = False  # aparelho na posição errada para este formato?
        self.orientation_check = 0.0
        self.change_state("title")

    # ---------- Máquina de estados ----------

    def change_state(self, name, **kwargs):
        """Troca de tela. kwargs são repassados para a nova tela
        (ex.: phase_index=1 diz qual fase carregar)."""
        self.state = STATES[name](self, **kwargs)
        self.state_name = name
        self.state_age = 0.0

    def start_new_run(self):
        """Zera as estatísticas e começa a fase 1."""
        self.run = {
            "routes_blocked": 0,
            "cartels_down": 0,
            "money_spent": 0.0,
            "violence": 0.0,
            "drugs_start": None,  # % de droga chegando no início da 1ª fase
            "drugs_end": None,    # % de droga chegando no fim da última fase
        }
        self.go_to_phase(0)

    def go_to_phase(self, index):
        """Vai para a fase 'index' ou, se elas acabaram, para a tela final."""
        if index < len(PHASES):
            self.change_state("playing", phase_index=index)
        else:
            self.change_state("ending")

    def finish_phase(self, index, sim):
        """Chamado quando o tempo de uma fase acaba: guarda os números e
        decide a próxima tela (fact card, se a fase tiver um)."""
        self.run["routes_blocked"] += sim.routes_blocked
        self.run["cartels_down"] += sim.cartels_down
        self.run["money_spent"] += sim.money_spent
        self.run["violence"] = sim.violence
        if self.run["drugs_start"] is None:
            self.run["drugs_start"] = sim.start_level
        self.run["drugs_end"] = sim.settled_level()

        if PHASES[index].get("fact"):
            self.change_state("fact_card", phase_index=index)
        else:
            self.go_to_phase(index + 1)

    # ---------- Laço principal ----------

    # ---------- Toque e orientação (versão web) ----------

    def _as_click(self, event):
        """Transforma toques e cliques num único tipo de evento.
        Retorna um MOUSEBUTTONDOWN (com touch=True se veio de um dedo),
        ou None se o evento deve ser ignorado por ser repetido."""
        if event.type == pygame.FINGERDOWN:
            # O dedo vem em coordenadas de 0 a 1; convertemos para pixels do jogo.
            pos = (int(event.x * settings.WIDTH), int(event.y * settings.HEIGHT))
            touch = True
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if getattr(event, "touch", False):
                # Cópia de "mouse" que o sistema cria a partir de um toque. O toque
                # de verdade já chega como FINGERDOWN (e esta cópia às vezes vem
                # com a posição errada), então ela é ignorada.
                return None
            pos = event.pos
            touch = False
        else:
            return None
        # O mesmo toque pode chegar como "dedo" e como "mouse": só vale o primeiro.
        # Usamos o relógio REAL (get_ticks): o tempo do jogo pode andar mais
        # devagar se o navegador desenhar poucos quadros por segundo.
        now = pygame.time.get_ticks() / 1000.0
        if now - self.last_click_time < DUPLICATE_CLICK_WINDOW:
            return None
        self.last_click_time = now
        self.last_input_touch = touch
        return pygame.event.Event(pygame.MOUSEBUTTONDOWN, button=1, pos=pos, touch=touch)

    def _check_orientation(self, dt):
        """No navegador, pergunta à página se o aparelho está na posição certa.
        (Só a cada meio segundo: não precisa ser a cada quadro.)
        - Formato em pé (celular): avisa só se for um aparelho de TOQUE deitado.
          No navegador de um computador o jogo em pé aparece normalmente.
        - Formato deitado: avisa se a tela estiver em pé."""
        if not IS_WEB:
            return
        self.orientation_check -= dt
        if self.orientation_check > 0:
            return
        self.orientation_check = 0.5
        try:
            import platform  # no pygbag, platform.window é a janela do navegador
            win = platform.window
            standing = win.innerHeight > win.innerWidth
            if settings.PORTRAIT:
                touch_device = bool(win.matchMedia("(pointer: coarse)").matches)
                self.wrong_orientation = touch_device and not standing
            else:
                self.wrong_orientation = standing
        except Exception:
            self.wrong_orientation = False

    def _draw_rotate_screen(self):
        self.screen.fill(settings.BG)
        cx, cy = settings.WIDTH // 2, settings.HEIGHT // 2
        # Desenho simples de um celular na posição CERTA, com uma seta curva.
        size = (120, 210) if settings.PORTRAIT else (210, 120)
        phone = pygame.Rect(0, 0, *size)
        phone.center = (cx, cy - 140)
        pygame.draw.rect(self.screen, settings.TEXT, phone, 8, border_radius=18)
        arc = pygame.Rect(0, 0, 300, 300)
        arc.center = phone.center
        pygame.draw.arc(self.screen, settings.ACCENT, arc, 0.2, 1.3, 8)
        text = "Turn your phone upright to play" if settings.PORTRAIT else "Rotate your phone to play"
        ui.draw_wrapped(self.screen, text, self.fonts["huge"], settings.TEXT, cx, cy + 40,
                        settings.WIDTH - 60)

    # ---------- Laço principal ----------

    async def loop(self):
        while self.running:
            # dt = segundos desde o último quadro. Usar dt faz o jogo andar na
            # mesma velocidade em computadores rápidos ou lentos. O limite de
            # 0.1 evita "pulos" se a janela travar por um instante.
            dt = min(self.clock.tick(settings.FPS) / 1000.0, 0.1)
            self.idle_time += dt
            self.state_age += dt
            self._check_orientation(dt)

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                elif event.type == pygame.KEYDOWN and event.key == pygame.K_f and not IS_WEB:
                    pygame.display.toggle_fullscreen()
                elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE and not IS_WEB:
                    self.running = False
                elif event.type in (pygame.MOUSEBUTTONDOWN, pygame.FINGERDOWN):
                    self.idle_time = 0.0
                    click = self._as_click(event)
                    if click is not None and not self.wrong_orientation:
                        self.state.handle_event(click)
                elif event.type in (pygame.MOUSEMOTION, pygame.FINGERMOTION):
                    self.idle_time = 0.0
                    if event.type == pygame.MOUSEMOTION and not getattr(event, "touch", False):
                        self.last_input_touch = False  # voltou a usar mouse de verdade

            if self.wrong_orientation:
                # Aparelho na posição errada: o jogo fica pausado mostrando o aviso.
                self._draw_rotate_screen()
            else:
                # Visitante foi embora no meio da partida? Volta para o início,
                # para o próximo visitante encontrar a tela inicial.
                if self.state_name != "title" and self.idle_time > settings.INACTIVITY_TIMEOUT:
                    self.idle_time = 0.0
                    self.change_state("title")

                self.state.update(dt)
                self.state.draw(self.screen)

                # "Fade": cada tela nova surge a partir do preto, suavemente.
                if self.state_age < settings.FADE_DURATION:
                    self.fade.set_alpha(int(255 * (1 - self.state_age / settings.FADE_DURATION)))
                    self.screen.blit(self.fade, (0, 0))

            pygame.display.flip()
            await asyncio.sleep(0)  # devolve o controle ao navegador (no PC, não faz nada)

        pygame.quit()
        sys.exit()


async def main():
    await Game().loop()


if __name__ == "__main__":
    asyncio.run(main())
