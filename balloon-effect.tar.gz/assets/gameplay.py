# gameplay.py
# A LÓGICA de uma fase: rotas, carregamentos (pontinhos), bloqueios,
# cartéis, violência e o efeito balão. Este arquivo não desenha nada na
# tela — só faz as contas. Separar lógica de desenho deixa cada parte mais
# fácil de entender e de testar.

import math
import random

import settings


def distance(a, b):
    """Distância em linha reta entre dois pontos (x, y)."""
    return math.hypot(b[0] - a[0], b[1] - a[1])


def distance_to_segment(p, a, b):
    """Distância do ponto p até o segmento de reta a-b.
    Usada para saber se o clique do mouse foi 'em cima' de uma rota."""
    ax, ay = a
    bx, by = b
    px, py = p
    dx, dy = bx - ax, by - ay
    length_sq = dx * dx + dy * dy
    if length_sq == 0:
        return distance(p, a)
    # t = posição da projeção de p sobre o segmento (0 = em a, 1 = em b)
    t = ((px - ax) * dx + (py - ay) * dy) / length_sq
    t = max(0.0, min(1.0, t))
    closest = (ax + t * dx, ay + t * dy)
    return distance(p, closest)


def place_rect(place):
    """Retângulo (x, y, largura, altura) de um lugar do mapa."""
    w, h = place["size"]
    x, y = place["pos"]
    return (x - w / 2, y - h / 2, w, h)


def point_in_rect(p, rect):
    x, y, w, h = rect
    return x <= p[0] <= x + w and y <= p[1] <= y + h


class Route:
    """Uma rota de tráfico: uma linha com vários pontos (uma 'polilinha')."""

    def __init__(self, data, places):
        self.id = data["id"]
        self.name = data["name"]
        self.cost = data["cost"]
        self.thin = data.get("thin", False)     # rotas pequenas são desenhadas mais finas
        self.hidden = data.get("hidden", False)  # rota reserva, ainda não aberta
        # "group": rotas que só aparecem quando um cartel cai e se divide.
        # Elas NÃO são usadas como reserva comum.
        self.group = data.get("group")

        self.blocked = False      # o jogador bloqueou
        self.military = False     # o bloqueio foi militar
        self.dismantled = False   # a rota sumiu porque o cartel dono dela caiu
        self.blocked_for = 0.0    # há quanto tempo está bloqueada (para animar o X)

        # Transforma nomes de lugares ("mexico") em coordenadas (x, y).
        self.points = []
        for p in data["path"]:
            if isinstance(p, str):
                self.points.append(places[p]["pos"])
            else:
                self.points.append(tuple(p))

        # Comprimento de cada trecho e o total: precisamos disso para
        # mover os pontinhos com velocidade constante ao longo da rota.
        self.segment_lengths = [distance(a, b) for a, b in zip(self.points, self.points[1:])]
        self.length = sum(self.segment_lengths)

        # Ponto onde fica o X do bloqueio (perto da fronteira dos EUA).
        self.block_distance = self.length * data.get("block_at", 0.75)

        # FLUXO: quanto da droga total passa por aqui (0 a 1).
        # "target_flow" é para onde o fluxo está indo; "flow" é o valor atual.
        # O fluxo atual anda aos poucos até o alvo — é isso que faz o
        # medidor subir de forma gradual quando uma rota nova é aberta.
        self.target_flow = data.get("flow", 0.0)
        self.flow = self.target_flow

        self.spawn_progress = 0.0   # acumulador para criar pontinhos
        self.highlight_time = 0.0   # tempo restante de destaque (rota nova)

    def point_at(self, dist):
        """Retorna a posição (x, y) a 'dist' pixels do início da rota."""
        for (a, b), seg_len in zip(zip(self.points, self.points[1:]), self.segment_lengths):
            if dist <= seg_len:
                t = dist / seg_len if seg_len else 0
                return (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t)
            dist -= seg_len
        return self.points[-1]

    def distance_from(self, pos):
        """Menor distância entre 'pos' e qualquer trecho da rota."""
        return min(distance_to_segment(pos, a, b) for a, b in zip(self.points, self.points[1:]))

    @property
    def is_open(self):
        """Aberta = visível, não bloqueada e não desmontada."""
        return not self.hidden and not self.blocked and not self.dismantled


class Cartel:
    """Um grande cartel (fase 2). Derrubá-lo desmonta as rotas dele, mas
    o cartel se divide em grupos menores, cada um com sua rota pequena."""

    def __init__(self, data):
        self.place = data["place"]
        self.name = data["name"]
        self.cost = data["cost"]
        self.route_ids = data["routes"]
        self.split_places = data["split_places"]
        self.split_routes = data["split_routes"]
        self.taken_down = False


class Shipment:
    """Um carregamento (pontinho) andando por uma rota."""

    def __init__(self, route):
        self.route = route
        self.dist = 0.0      # quantos pixels já andou desde a origem
        self.done = False    # True quando chegou aos EUA ou foi apreendido
        self.seized = False  # True se foi parado num bloqueio

    def update(self, dt):
        before = self.dist
        self.dist += settings.SHIPMENT_SPEED * dt

        # Se a rota está bloqueada e o pontinho acabou de passar pelo X,
        # ele é apreendido. Pontinhos que JÁ tinham passado do X continuam:
        # a droga que já cruzou não volta.
        r = self.route
        if r.blocked and before < r.block_distance <= self.dist:
            self.done = True
            self.seized = True
        elif self.dist >= r.length:
            self.done = True

    @property
    def pos(self):
        return self.route.point_at(self.dist)


class PhaseSimulation:
    """Tudo o que acontece durante uma fase."""

    def __init__(self, phase, violence=0.0):
        self.phase = phase
        self.places = phase["places"]
        self.routes = [Route(r, self.places) for r in phase["routes"]]
        self.route_by_id = {r.id: r for r in self.routes}
        self.cartels = [Cartel(c) for c in phase.get("cartels", [])]

        # Lugares escondidos (ex.: grupos pequenos que só surgem quando um
        # cartel cai). Guardamos o conjunto de ids que NÃO devem aparecer.
        self.hidden_places = {pid for pid, p in self.places.items() if p.get("hidden")}

        self.budget = phase["budget"]
        self.time_left = float(phase["duration"])
        self.shipments = []

        # Desvios "em andamento". Cada item é um dicionário:
        #   time       -> segundos até os traficantes reagirem
        #   amount     -> quanto fluxo foi desviado
        #   efficiency -> que fração desse fluxo volta a chegar
        #   cartel     -> se veio da queda de um cartel, qual (senão None)
        self.pending_reroutes = []

        # Violência: continua de uma fase para a outra (vem do jogo).
        # violence_rate > 0 faz a violência subir sozinha com o tempo
        # (cada bloqueio militar deixa um conflito "aceso").
        self.violence = violence
        self.violence_rate = 0.0

        # Vira True na primeira vez que os traficantes acham uma rota nova.
        # A partir daí a tela roda o resto da fase em velocidade acelerada:
        # o visitante já viu o efeito balão e não precisa esperar tanto.
        self.fast_forward = False

        # Estatísticas da fase (usadas depois na tela final).
        self.routes_blocked = 0
        self.cartels_down = 0
        self.money_spent = 0.0
        self.start_level = self.drugs_reaching()

        # Aviso de que os traficantes reagiram (ex.: "Traffickers moved...").
        # A tela decide se mostra este aviso ou outro (ver MessageBar).
        self.notice = ""
        self.notice_time = 0.0

        # Acontecimentos que a tela usa para animações (apreensões,
        # chegadas aos EUA). A tela lê e esvazia esta lista a cada quadro.
        self.events = []

    # ---------- Consultas ----------

    def drugs_reaching(self):
        """Fração da droga que está chegando aos EUA agora (0 a 1).
        É simplesmente a soma do fluxo das rotas abertas."""
        return sum(r.flow for r in self.routes if r.is_open)

    def settled_level(self):
        """Quanto vai chegar quando os desvios pendentes terminarem.
        Usado no resumo final, para não "premiar" um bloqueio feito no
        último segundo, antes de os traficantes terem tempo de reagir."""
        level = sum(r.target_flow for r in self.routes if r.is_open)
        level += sum(p["amount"] * p["efficiency"] for p in self.pending_reroutes)
        return min(1.0, level)

    @property
    def finished(self):
        return self.time_left <= 0

    def visible_routes(self):
        """Rotas que aparecem no mapa (as de cartéis derrubados somem)."""
        return [r for r in self.routes if not r.hidden and not r.dismantled]

    def visible_places(self):
        return [(pid, p) for pid, p in self.places.items() if pid not in self.hidden_places]

    def route_at(self, pos, touch=False):
        """Qual rota ABERTA está sob o mouse (ou None). Escolhe a mais próxima.
        touch=True aceita um ponto mais longe da linha (toque de dedo)."""
        limit = settings.ROUTE_TOUCH_DISTANCE if touch else settings.ROUTE_CLICK_DISTANCE
        best, best_dist = None, limit
        for r in self.routes:
            if not r.is_open:
                continue
            d = r.distance_from(pos)
            if d <= best_dist:
                best, best_dist = r, d
        return best

    def cartel_at(self, pos, touch=False):
        """Qual cartel (ainda de pé) está sob o mouse (ou None).
        touch=True aumenta um pouco a caixa clicável (toque de dedo)."""
        pad = settings.TOUCH_PADDING if touch else 0
        for c in self.cartels:
            x, y, w, h = place_rect(self.places[c.place])
            if not c.taken_down and point_in_rect(pos, (x - pad, y - pad, w + 2 * pad, h + 2 * pad)):
                return c
        return None

    def cheapest_action(self):
        costs = [r.cost for r in self.routes if r.is_open]
        costs += [c.cost for c in self.cartels if not c.taken_down]
        return min(costs) if costs else None

    def out_of_budget(self):
        cheapest = self.cheapest_action()
        return cheapest is None or self.budget < cheapest

    # ---------- Ações do jogador ----------

    def block(self, route, military=False):
        """O jogador bloqueou uma rota. Aqui começa o efeito balão."""
        if not route.is_open or self.budget < route.cost:
            return False

        self.budget -= route.cost
        self.money_spent += route.cost
        self.routes_blocked += 1
        route.blocked = True
        route.military = military

        # O fluxo que passava por essa rota NÃO some: ele fica "esperando"
        # alguns segundos (os traficantes procurando outro caminho).
        # Usamos target_flow (e não flow) para não perder a parte que ainda
        # estava crescendo, caso a rota fosse nova.
        displaced = route.target_flow
        route.flow = 0.0
        route.target_flow = 0.0

        delay = self.phase["reroute_delay"]
        efficiency = self.phase["reroute_efficiency"]
        if military:
            # Bloqueio militar: os traficantes demoram mais para se
            # reorganizar e perdem mais carga... mas a violência explode.
            delay *= settings.MILITARY_DELAY_FACTOR
            efficiency -= settings.MILITARY_EFFICIENCY_PENALTY
            self._add_violence(settings.VIOLENCE_PER_MILITARY)
            self.violence_rate += settings.VIOLENCE_MILITARY_RATE
        else:
            self._add_violence(settings.VIOLENCE_PER_BLOCK)

        if displaced > 0:
            self.pending_reroutes.append(
                {"time": delay, "amount": displaced, "efficiency": efficiency, "cartel": None})

        return True

    def take_down(self, cartel):
        """O jogador derrubou um cartel (fase 2).
        As rotas dele somem, e depois de alguns segundos o cartel
        reaparece dividido em vários grupos menores."""
        if cartel.taken_down or self.budget < cartel.cost:
            return False

        self.budget -= cartel.cost
        self.money_spent += cartel.cost
        self.cartels_down += 1
        cartel.taken_down = True

        displaced = 0.0
        for rid in cartel.route_ids:
            r = self.route_by_id[rid]
            if r.is_open:
                displaced += r.target_flow
            r.dismantled = True
            r.flow = 0.0
            r.target_flow = 0.0

        # Guerra pela sucessão: derrubar um cartel também gera violência.
        self._add_violence(settings.VIOLENCE_PER_TAKEDOWN)
        self.pending_reroutes.append({
            "time": self.phase["reroute_delay"],
            "amount": displaced,
            "efficiency": self.phase["reroute_efficiency"],
            "cartel": cartel,
        })
        return True

    # ---------- Atualização (chamada a cada quadro) ----------

    def update(self, dt):
        self.time_left = max(0.0, self.time_left - dt)
        self.notice_time = max(0.0, self.notice_time - dt)
        self._add_violence(self.violence_rate * dt)

        self._update_reroutes(dt)
        self._update_flows(dt)
        self._spawn_shipments(dt)

        for s in self.shipments:
            s.update(dt)
            if s.done:
                kind = "seized" if s.seized else "arrived"
                self.events.append((kind, s.pos))
        self.shipments = [s for s in self.shipments if not s.done]

    def _update_reroutes(self, dt):
        """O CORAÇÃO DO EFEITO BALÃO.
        Depois do atraso, o fluxo desviado reaparece em outro lugar."""
        still_waiting = []
        for item in self.pending_reroutes:
            item["time"] -= dt
            if item["time"] > 0:
                still_waiting.append(item)
                continue

            amount = item["amount"] * item["efficiency"]
            if item["cartel"] is not None:
                self._split_cartel(item["cartel"], amount)
                self.fast_forward = True
                continue

            target = self._choose_new_route()
            if target is None:
                continue  # nenhum caminho sobrou: essa parte se perde
            target.target_flow += amount
            target.highlight_time = settings.NEW_ROUTE_HIGHLIGHT
            self.fast_forward = True
            self._notify(f"Traffickers moved to: {target.name}")
        self.pending_reroutes = still_waiting

    def _split_cartel(self, cartel, amount):
        """O cartel caído vira vários grupos pequenos. O fluxo dele é
        dividido igualmente entre as rotas novas desses grupos."""
        self.hidden_places.add(cartel.place)
        for pid in cartel.split_places:
            self.hidden_places.discard(pid)
        new_routes = [self.route_by_id[rid] for rid in cartel.split_routes]
        for r in new_routes:
            r.hidden = False
            r.target_flow += amount / len(new_routes)
            r.highlight_time = settings.NEW_ROUTE_HIGHLIGHT
        self._notify(f"The {cartel.name} split into {len(new_routes)} smaller groups!")

    def _choose_new_route(self):
        open_routes = [r for r in self.routes if r.is_open]
        # Reservas: escondidas, que não são de um grupo de cartel e que não
        # foram desmontadas junto com um cartel derrubado.
        reserves = [r for r in self.routes if r.hidden and r.group is None and not r.dismantled]

        # Fase do fentanil: os traficantes preferem abrir rotas NOVAS.
        if self.phase.get("prefer_new_routes") and reserves:
            r = random.choice(reserves)
            r.hidden = False
            return r
        # Normal: primeiro uma rota que já existe e está aberta...
        if open_routes:
            return random.choice(open_routes)
        # ...e, se não sobrar nenhuma, abre uma rota reserva.
        if reserves:
            r = reserves[0]
            r.hidden = False
            return r
        return None

    def _update_flows(self, dt):
        """Faz o fluxo atual de cada rota andar aos poucos até o alvo."""
        step = self.phase["ramp_speed"] * dt
        for r in self.routes:
            r.highlight_time = max(0.0, r.highlight_time - dt)
            if r.blocked:
                r.blocked_for += dt
            if r.flow < r.target_flow:
                r.flow = min(r.target_flow, r.flow + step)
            elif r.flow > r.target_flow:
                r.flow = max(r.target_flow, r.flow - step)

    def _spawn_shipments(self, dt):
        """Cria pontinhos em cada rota, proporcionais ao fluxo dela.
        Mais fluxo = mais pontinhos. Assim o jogador VÊ o desvio acontecer."""
        rate = self.phase["shipments_per_second"]
        for r in self.routes:
            if not r.is_open or r.flow <= 0:
                continue
            r.spawn_progress += r.flow * rate * dt
            while r.spawn_progress >= 1:
                r.spawn_progress -= 1
                self.shipments.append(Shipment(r))

    def _add_violence(self, amount):
        self.violence = min(settings.VIOLENCE_MAX, self.violence + amount)

    def _notify(self, text):
        self.notice = text
        self.notice_time = settings.NOTICE_DURATION
