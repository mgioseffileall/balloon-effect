# mapview.py
# Desenha o MAPA de uma fase (regiões, rotas, lugares, pontinhos, X dos
# bloqueios) e as pequenas animações (explosões, textos que sobem).
# Fica separado de screens.py porque é usado por duas telas: a fase
# jogável e o "mapa de demonstração" que roda atrás da tela inicial.

import pygame

import settings
import ui
from gameplay import place_rect

PLACE_COLORS = {
    "source": settings.PLACE_SOURCE,
    "transit": settings.PLACE_TRANSIT,
    "destination": settings.PLACE_DEST,
    "cartel": settings.PLACE_CARTEL,
    "group": settings.PLACE_GROUP,
}


# ======================================================================
# Efeitos visuais curtos
# ======================================================================
class Effects:
    """Guarda animações curtas. Cada uma tem um tipo, uma posição e uma
    idade; quando fica "velha" demais, é apagada."""

    LIFETIME = {"burst": 0.5, "pulse": 0.45, "float": 1.4}

    def __init__(self):
        self.items = []

    def add(self, kind, pos, text="", color=settings.TEXT):
        self.items.append({"kind": kind, "pos": pos, "age": 0.0, "text": text, "color": color})

    def update(self, dt):
        for item in self.items:
            item["age"] += dt
        self.items = [i for i in self.items if i["age"] < self.LIFETIME[i["kind"]]]

    def draw(self, surface, fonts):
        for item in self.items:
            t = item["age"] / self.LIFETIME[item["kind"]]   # 0 = começou, 1 = acabou
            x, y = item["pos"]
            if item["kind"] == "burst":
                # Anel vermelho que cresce: carregamento apreendido no bloqueio.
                pygame.draw.circle(surface, settings.BLOCK_X, (int(x), int(y)), int(6 + t * 26), 3)
            elif item["kind"] == "pulse":
                # Anel branco pequeno: carregamento chegando aos EUA.
                color = ui.mix(settings.SHIPMENT, settings.PLACE_DEST, t)
                pygame.draw.circle(surface, color, (int(x), int(y)), int(4 + t * 16), 2)
            elif item["kind"] == "float":
                # Texto que sobe e desaparece (ex.: "-$2.0B").
                ui.draw_text(surface, item["text"], fonts["medium"], item["color"],
                             (x, y - 45 * t), alpha=int(255 * (1 - t)))


# ======================================================================
# Mapa
# ======================================================================
def draw_map(surface, sim, fonts, hovered_route=None, hovered_cartel=None, military=False):
    phase = sim.phase
    _draw_regions(surface, phase, fonts)
    _draw_labels(surface, phase, fonts)
    _draw_links(surface, phase)
    _draw_routes(surface, sim, hovered_route, military)
    # Pontinhos antes dos lugares: assim parecem passar "por dentro" deles.
    _draw_shipments(surface, sim)
    _draw_places(surface, sim, fonts, hovered_cartel)
    _draw_blocks(surface, sim)


def _draw_regions(surface, phase, fonts):
    for region in phase.get("regions", []):
        rect = pygame.Rect(region["rect"])
        pygame.draw.rect(surface, settings.REGION, rect, border_radius=18)
        pygame.draw.rect(surface, settings.SEA_LABEL, rect, 1, border_radius=18)
        ui.draw_text(surface, region["name"], fonts["tiny"], settings.SEA_LABEL,
                     (rect.x + 14, rect.bottom - 10), "bottomleft")


def _draw_labels(surface, phase, fonts):
    for label in phase.get("labels", []):
        ui.draw_text(surface, label["text"], fonts["small"], settings.SEA_LABEL, label["pos"])


def _draw_links(surface, phase):
    places = phase["places"]
    for a, b in phase.get("links", []):
        ui.draw_dashed_line(surface, settings.LINK, places[a]["pos"], places[b]["pos"], 2)


def _draw_routes(surface, sim, hovered, military):
    for r in sim.visible_routes():
        base = 3 if r.thin else 6
        if r.blocked or r.dismantled:
            color, width = settings.ROUTE_BLOCKED, max(2, base - 2)
        elif r is hovered:
            color = settings.ROUTE_HOVER_MILITARY if military else settings.ROUTE_HOVER
            width = base + 5
        elif r.highlight_time > 0:
            # Rota nova "pisca" para chamar a atenção do jogador.
            blink = int(r.highlight_time * 6) % 2 == 0
            color = settings.ROUTE_NEW if blink else settings.ROUTE_OPEN
            width = base + 2
        else:
            color, width = settings.ROUTE_OPEN, base
        pygame.draw.lines(surface, color, False, r.points, width)
        # Círculos nas "dobras" deixam as junções das linhas arredondadas.
        for p in r.points:
            pygame.draw.circle(surface, color, (int(p[0]), int(p[1])), width // 2)


def _draw_shipments(surface, sim):
    for s in sim.shipments:
        radius = 3 if s.route.thin else 5
        # "Rastro": duas bolinhas menores e mais escuras atrás do pontinho.
        for back, shade in ((14, (90, 95, 115)), (7, (170, 175, 190))):
            if s.dist > back:
                x, y = s.route.point_at(s.dist - back)
                pygame.draw.circle(surface, shade, (int(x), int(y)), max(1, radius - 2))
        x, y = s.pos
        pygame.draw.circle(surface, settings.SHIPMENT, (int(x), int(y)), radius)


def _draw_places(surface, sim, fonts, hovered_cartel):
    fallen = {c.place for c in sim.cartels if c.taken_down}
    hovered_place = hovered_cartel.place if hovered_cartel else None

    for pid, place in sim.visible_places():
        rect = pygame.Rect([int(v) for v in place_rect(place)])
        color = PLACE_COLORS[place["kind"]]
        border, border_w = settings.PLACE_BORDER, 2
        if pid in fallen:
            color = ui.mix(color, settings.BG, 0.6)
        if pid == hovered_place:
            color = ui.mix(color, (255, 255, 255), 0.15)
            border, border_w = settings.ROUTE_HOVER, 4

        pygame.draw.rect(surface, color, rect, border_radius=10)
        pygame.draw.rect(surface, border, rect, border_w, border_radius=10)
        font = fonts["small"] if rect.height < 45 else fonts["medium"]
        if place["kind"] == "group":
            font = fonts["tiny"]
        ui.draw_text(surface, place["name"], font, settings.TEXT, rect.center)

        if pid in fallen:
            # Cartel derrubado, esperando para se dividir: X grande por cima.
            pygame.draw.line(surface, settings.BLOCK_X, rect.topleft, rect.bottomright, 5)
            pygame.draw.line(surface, settings.BLOCK_X, rect.bottomleft, rect.topright, 5)


def _draw_blocks(surface, sim):
    for r in sim.routes:
        if not r.blocked:
            continue
        x, y = r.point_at(r.block_distance)
        # Animação de "pop": o X aparece grande e encolhe até o tamanho normal.
        grow = max(0.0, 1.0 - r.blocked_for / 0.25)
        size = (9 if r.thin else 13) * (1 + grow * 0.8)
        bg = settings.MILITARY if r.military else settings.HEADER_BG
        if r.military:
            box = pygame.Rect(0, 0, size * 3, size * 3)
            box.center = (int(x), int(y))
            pygame.draw.rect(surface, bg, box, border_radius=4)
        else:
            pygame.draw.circle(surface, bg, (int(x), int(y)), int(size * 1.5))
        w = 5 if r.thin else 7
        pygame.draw.line(surface, settings.BLOCK_X, (x - size, y - size), (x + size, y + size), w)
        pygame.draw.line(surface, settings.BLOCK_X, (x - size, y + size), (x + size, y - size), w)
