# ui.py
# Funções pequenas de desenho reaproveitadas por várias telas:
# texto, quebra de linha, medidores, botões e linhas tracejadas.

import math

import pygame

import settings


def load_fonts():
    """Carrega as fontes uma vez só (carregar fonte a cada quadro é lento).
    Font(None, ...) usa a fonte padrão do Pygame, que existe em qualquer
    computador — assim não dependemos de arquivos externos."""
    sizes = {"huge": 104, "big": 60, "header": 46, "medium": 36, "small": 27, "tiny": 22}
    return {name: pygame.font.Font(None, int(size * settings.FONT_SCALE))
            for name, size in sizes.items()}


def draw_text(surface, text, font, color, pos, anchor="center", alpha=255):
    """Desenha um texto. 'anchor' diz qual ponto do texto fica em 'pos'
    (ex.: "center", "topleft", "midright"). 'alpha' = transparência (0 a 255)."""
    image = font.render(text, True, color)
    if alpha < 255:
        image.set_alpha(alpha)
    rect = image.get_rect(**{anchor: (int(pos[0]), int(pos[1]))})
    surface.blit(image, rect)
    return rect


def wrap_text(text, font, max_width):
    """Quebra um texto longo em várias linhas que cabem em max_width."""
    words = text.split()
    lines, current = [], ""
    for word in words:
        test = f"{current} {word}".strip()
        if font.size(test)[0] <= max_width:
            current = test
        else:
            lines.append(current)
            current = word
    if current:
        lines.append(current)
    return lines


def draw_wrapped(surface, text, font, color, center_x, top_y, max_width, line_height=None):
    """Desenha um texto longo centralizado, quebrando em várias linhas.
    Retorna o y logo abaixo da última linha (útil para empilhar coisas)."""
    line_height = line_height or font.get_linesize()
    y = top_y
    for line in wrap_text(text, font, max_width):
        draw_text(surface, line, font, color, (center_x, y + line_height // 2))
        y += line_height
    return y


def fit_font(fonts, text, max_width, order=("medium", "small", "tiny")):
    """A maior fonte (da lista) em que o texto cabe na largura."""
    for name in order:
        if fonts[name].size(text)[0] <= max_width:
            return fonts[name]
    return fonts[order[-1]]


def mix(color_a, color_b, t):
    """Mistura duas cores. t=0 -> color_a, t=1 -> color_b."""
    t = max(0.0, min(1.0, t))
    return tuple(int(a + (b - a) * t) for a, b in zip(color_a, color_b))


def draw_meter(surface, fonts, rect, label, value, color, text=None):
    """Barra horizontal com rótulo em cima e valor à direita.
    'value' vai de 0 a 1. 'text' troca o número mostrado (padrão: %)."""
    rect = pygame.Rect(rect)
    draw_text(surface, label, fonts["tiny"], settings.TEXT_DIM, (rect.x, rect.y - 5), "bottomleft")
    pygame.draw.rect(surface, settings.METER_BG, rect, border_radius=5)
    fill = rect.copy()
    fill.width = int(rect.width * max(0.0, min(1.0, value)))
    if fill.width > 0:
        pygame.draw.rect(surface, color, fill, border_radius=5)
    if text is None:
        text = f"{value * 100:.0f}%"
    draw_text(surface, text, fonts["small"], settings.TEXT, (rect.right + 8, rect.centery), "midleft")


def draw_dashed_line(surface, color, a, b, width=2, dash=10, gap=8):
    """Linha tracejada (o Pygame não tem uma pronta)."""
    length = math.hypot(b[0] - a[0], b[1] - a[1])
    if length == 0:
        return
    dx, dy = (b[0] - a[0]) / length, (b[1] - a[1]) / length
    pos = 0.0
    while pos < length:
        end = min(pos + dash, length)
        pygame.draw.line(surface, color,
                         (a[0] + dx * pos, a[1] + dy * pos),
                         (a[0] + dx * end, a[1] + dy * end), width)
        pos += dash + gap


class Button:
    """Botão retangular que muda de cor quando o mouse passa por cima.
    'selected' serve para botões de escolha (ex.: POLICE / MILITARY)."""

    def __init__(self, text, center, size=(260, 70), color=None):
        self.text = text
        self.rect = pygame.Rect(0, 0, *size)
        self.rect.center = center
        self.color = color or settings.BUTTON
        self.selected = True

    def is_hovered(self):
        return self.rect.collidepoint(pygame.mouse.get_pos())

    def is_clicked(self, event):
        if event.type != pygame.MOUSEBUTTONDOWN or event.button != 1:
            return False
        rect = self.rect
        if getattr(event, "touch", False):
            # Toque de dedo: área clicável um pouco maior que o desenho.
            rect = rect.inflate(2 * settings.TOUCH_PADDING, 2 * settings.TOUCH_PADDING)
        return rect.collidepoint(event.pos)

    def draw(self, surface, font):
        if not self.selected:
            color = settings.BUTTON_OFF
        else:
            color = self.color
        if self.is_hovered():
            color = mix(color, (255, 255, 255), 0.2)
        pygame.draw.rect(surface, color, self.rect, border_radius=12)
        if self.selected:
            pygame.draw.rect(surface, settings.TEXT, self.rect, 2, border_radius=12)
        text_color = settings.TEXT if self.selected else settings.TEXT_DIM
        draw_text(surface, self.text, font, text_color, self.rect.center)
