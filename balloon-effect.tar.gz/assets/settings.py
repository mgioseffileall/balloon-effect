# settings.py
# Constantes gerais do jogo (tamanho da janela, cores, regras que valem
# para todas as fases). Ficam aqui, separadas, para que seja fácil ajustar
# sem procurar números "mágicos" espalhados pelo código.
# Os números específicos de cada fase ficam em phases.py.

import os
import sys

# ---------- Formato da tela ----------
# O jogo tem DOIS formatos:
#   - deitado (1280x720): notebook da mesa de exposição;
#   - em pé (720x1280): versão web, para jogar no celular.
# No navegador (pygbag, sys.platform == "emscripten") ele fica em pé.
# Para testar o formato em pé no computador, rode com a variável de
# ambiente BALLOON_LAYOUT=portrait.
PORTRAIT = sys.platform == "emscripten" or os.environ.get("BALLOON_LAYOUT") == "portrait"

if PORTRAIT:
    WIDTH, HEIGHT = 720, 1280
    HEADER_HEIGHT = 160   # o topo tem 3 linhas: título, orçamento/tempo, medidores
    FONT_SCALE = 1.3      # letras maiores: a tela do celular é pequena
else:
    WIDTH, HEIGHT = 1280, 720
    HEADER_HEIGHT = 90
    FONT_SCALE = 1.0

FPS = 60
TITLE = "The Balloon Effect"

# ---------- Cores (R, G, B) ----------
BG = (16, 26, 44)              # fundo azul-escuro (lembra o mar)
HEADER_BG = (10, 16, 28)
PANEL = (26, 38, 62)           # fundo de cartões e caixas
REGION = (24, 36, 58)          # área de um país que contém outros lugares
TEXT = (235, 238, 245)
TEXT_DIM = (150, 160, 180)
SEA_LABEL = (52, 72, 104)
ACCENT = (255, 205, 100)       # amarelo de destaque

PLACE_SOURCE = (120, 60, 50)   # país produtor
PLACE_TRANSIT = (60, 75, 100)  # países de passagem
PLACE_DEST = (40, 80, 150)     # destino (EUA)
PLACE_CARTEL = (125, 45, 85)   # grande cartel (clicável na fase 2)
PLACE_GROUP = (95, 55, 80)     # grupo pequeno que surge quando um cartel cai
PLACE_BORDER = (200, 210, 230)

ROUTE_OPEN = (225, 165, 60)    # rota ativa (amarelo-laranja)
ROUTE_HOVER = (255, 220, 130)  # rota sob o mouse
ROUTE_HOVER_MILITARY = (255, 120, 110)
ROUTE_BLOCKED = (70, 76, 92)   # rota bloqueada (cinza)
ROUTE_NEW = (255, 110, 60)     # rota recém-aberta pelos traficantes
LINK = (90, 100, 125)          # linha tracejada decorativa (não clicável)

SHIPMENT = (250, 250, 250)     # pontinhos (carregamentos)
BLOCK_X = (230, 40, 40)        # X vermelho do bloqueio
MILITARY = (70, 95, 55)        # verde-oliva dos bloqueios militares

METER_BG = (40, 48, 66)
METER_DRUGS = (220, 80, 80)
METER_MONEY = (90, 180, 110)
METER_VIOLENCE_LOW = (230, 190, 70)
METER_VIOLENCE_HIGH = (200, 30, 30)
BUTTON = (200, 70, 60)
BUTTON_HOVER = (230, 100, 80)
BUTTON_OFF = (45, 55, 78)

# ---------- Tempos das telas (segundos) ----------
PHASE_INTRO_DURATION = 7.0     # cartão de abertura de cada fase (o timer fica parado)
ENDING_DURATION = 20.0         # tela final antes de voltar ao início
INACTIVITY_TIMEOUT = 30.0      # sem ninguém mexer no mouse -> volta ao início
FADE_DURATION = 0.35           # "fade" ao trocar de tela
NOTICE_DURATION = 3.0          # quanto tempo "Traffickers moved to..." fica na tela
BUDGET_WARNING_DURATION = 2.0  # quanto tempo "Not enough budget" fica na tela
NEW_ROUTE_HIGHLIGHT = 3.0      # quanto tempo uma rota nova fica piscando

# ---------- Regras gerais ----------
SHIPMENT_SPEED = 140           # velocidade dos pontinhos, em pixels por segundo
FAST_FORWARD_SPEED = 2.0       # depois que os traficantes acham uma rota nova, a fase anda 2x mais rápido
ROUTE_CLICK_DISTANCE = 14      # quão perto da linha (em pixels) o clique precisa estar
# Dedos são bem menos precisos que o mouse: com toque, as áreas de clique
# crescem (o desenho na tela continua igual).
ROUTE_TOUCH_DISTANCE = 34      # distância aceita da linha num toque
TOUCH_PADDING = 16             # pixels extras em volta de botões e cartéis num toque

# Violência vai de 0 a 100 e se ACUMULA entre as fases.
VIOLENCE_MAX = 100.0
VIOLENCE_PER_BLOCK = 3.0       # bloqueio comum (polícia)
VIOLENCE_PER_TAKEDOWN = 10.0   # derrubar um cartel (guerra pela sucessão)
VIOLENCE_PER_MILITARY = 12.0   # bloqueio militar: salto imediato...
VIOLENCE_MILITARY_RATE = 0.35  # ...e mais isto por segundo, até o fim da fase

# Bloqueio militar: os traficantes demoram mais para reagir e perdem mais carga.
MILITARY_DELAY_FACTOR = 2.0        # atraso do desvio multiplicado por 2
MILITARY_EFFICIENCY_PENALTY = 0.15  # 15 pontos a menos de carga que volta a chegar

# Escala do medidor "Money spent" (4 fases x $5B = $20B no máximo).
MONEY_METER_MAX = 20.0

DISCLAIMER = "Numbers in this game are simplified. Events on the fact cards are real."
